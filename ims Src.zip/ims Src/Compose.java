
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Compose extends HttpServlet
{

    public Compose()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        String username = session.getAttribute("username").toString();
        PrintWriter out = res.getWriter();
        out.println("<html><body bgcolor='#99CCFF'>");
        out.println("<form action='./composemsg'>");
        out.println("<br>");
        out.println("<center>");
        out.println("Welcome to " + username + "@mailingsystem.com");
        out.println("</center>");
        out.println("<br>");
        out.println("<center><table>");
        out.println("<tr><td>To:</td><td><input type='text' name='To'></td></tr>");
        out.println("<br>");
        out.println("<tr><td>Subject:</td><td><input type='text' name='sub'></td></tr>");
        out.println("<br>");
        out.println("<tr><td>Cc:</td><td><input type='text' name='Cc'></td></tr>");
        out.println("<br>");
        out.println("<tr><td>Bcc:</td><td><input type='text' name='Bcc'></td></tr>");
        out.println("<br>");
        out.println("<tr><td>Send Message Area:</td></tr>");
        out.println("<br>");
        out.println("<tr><td><textarea name='message' rows='10' columns='60'></textarea></td>");
        out.println("<td>Atachment1<input type=file name='file1'><br>");
        out.println("Atachment2<input type=file name='file2'><br>");
        out.println("Atachment3<input type=file name='file3'><br></td>");
        out.println("</table></center>");
        out.println("<center><input type='submit' name='comp' value='Send'></center>");
        out.println("<center><input type='submit' name='comp' value='Save as draft'></center>");
        out.println("</form></body></html>");
    }
}
