import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Change extends HttpServlet
{

    public Change()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        PrintWriter out = res.getWriter();
        String username = session.getAttribute("username").toString();
        String old = req.getParameter("old");
        String npwd = req.getParameter("new");
        String cnew = req.getParameter("cnew");
        System.out.println("old is:" + old);
        System.out.println("pwd is:" + npwd);
        System.out.println("cnew is:" + cnew);
        System.out.println("username is:" + username);
        Connection con=null;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ims","ims");
            Statement stmt = con.createStatement(1005, 1008);
            ResultSet rs = stmt.executeQuery("select * from new_users_details where username='" + username + "'");
            if(rs.next())
                if(rs.getString(2).equals(old))
                {
                    if(npwd.equals(cnew))
                    {
                        PreparedStatement pstmt = con.prepareStatement("update new_users_details set userpwd='" + npwd + "',con_pwd='" + npwd + "' where username='" + username + "'");
                        pstmt.executeUpdate();
                        out.println("<html><body bgcolor='#99CCFF'>");
                        out.println("<br>");
                        out.println("<center>");
                        out.println("<b>Welcome to " + username + "@mailingsystem.com</b>");
                        out.println("</center>");
                        out.println("<br>");
                        out.println("<center>Your password has been Changed</center>");
                        out.println("</body></html>");
                    } else
                    {
                        out.println("<html><body bgcolor='#99CCFF'>");
                        out.println("<br>");
                        out.println("<center>");
                        out.println("<b>Welcome to " + username + "@mailingsystem.com</b>");
                        out.println("</center>");
                        out.println("<br>");
                        out.println("<center>verify conform password</center>");
                        out.println("</body></html>");
                    }
                } else
                {
                    out.println("<html><body bgcolor='#99CCFF'>");
                    out.println("<br>");
                    out.println("<center>");
                    out.println("<b>Welcome to " + username + "@mailingsystem.com</b>");
                    out.println("</center>");
                    out.println("<br>");
                    out.println("<center>verify old password</center>");
                    out.println("</body></html>");
                }
            con.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
    }
}
