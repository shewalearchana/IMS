

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class main extends HttpServlet
{

    public main()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        PrintWriter out = res.getWriter();
        String username = session.getAttribute("username").toString();
        out.println("<html>");
        out.println("<body bgcolor='#99CC88'>");
        out.println("<br>");
        out.println("<br>");
        out.println("<br>");
        out.println("<br>");
        out.println("<br>");
        out.println("<a href='./Inbox?username=" + username + "' target='right'>Inbox</a>");
        out.println("<br>");
        out.println("<br>");
        out.println("<a href='./Compose?username=" + username + "' target='right'>Compose</a>");
        out.println("<br>");
        out.println("<br>");
        out.println("<a href='./UpdateForm?username=" + username + "' target='right'>ChangeUser Profile</a>");
        out.println("<br>");
        out.println("<br>");
        out.println("<a href='./Address?username=" + username + "' target='right'>Address</a>");
        out.println("<br>");
        out.println("<br>");
        out.println("<a href='./SentMessage?username=" + username + "' target='right'>SentMessage</a>");
        out.println("<br>");
        out.println("<br>");
        out.println("<a href='./DraftMessage?username=" + username + "' target='right'>Draft</a>");
        out.println("<br>");
        out.println("<br>");
        out.println("<a href='./Logout?username=" + username + "' target='right'>Logout</a>");
    }
}
