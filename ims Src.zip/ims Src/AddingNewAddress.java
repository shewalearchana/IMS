import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AddingNewAddress extends HttpServlet
{

    public AddingNewAddress()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        PrintWriter out = res.getWriter();
        String username = session.getAttribute("username").toString();
        out.println("<html><body bgcolor='#99CCFF'>");
        out.println("<br>");
        out.println("<center>");
        out.println("Adding new address to " + username + "@graybound.com");
        out.println("</center>");
        out.println("<form action='./NewAddress' target='right'>");
        out.println("<center><table align='left'>");
        out.println("<tr><td>Name:</td><td><input type='text' name='name'></td></tr>");
        out.println("<br>");
        out.println("<tr><td>Nick Name:</td><td><input type='text' name='nname'></td></tr>");
        out.println("<br>");
        out.println("<tr><td>Emailid:</td><td><input type='text' name='emailid'></td></tr>");
        out.println("<br>");
        out.println("<tr><td>Address:</td><td><input type='text' name='address'></td></tr>");
        out.println("</table></center>");
        out.println("<br>");
        out.println("<br>");
        out.println("<center><input type='submit' name='add' value='Add'></center>");
        out.println("</from></body></html>");
    }
}
