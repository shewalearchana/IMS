// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MainPage.java

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class MainPage extends HttpServlet
{

    public MainPage()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        String username = req.getParameter("username");
        String pass = req.getParameter("pass");
        PrintWriter out = res.getWriter();
        System.out.println("username is:" + username);
        System.out.println("password is:" + pass);
        Connection con=null;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
              con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ims","ims");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from new_users_details where username='" + username + "' and userpwd='" + pass + "'");
            if(rs.next())
            {
                session.setAttribute("username", username);
                session.setAttribute("pass", pass);
                session.setAttribute("password", pass);
                out.println("<html>");
                out.println("<frameset cols='25%,75%'>");
                out.println("<frame name='left' src='./main'>");
                out.println("<frame name='right' src='./welcome.html'>");
                out.println("</frameset>");
                out.println("</html>");
            } else
            {
            	out.println("<html>");
                out.println("Error in username and password plz verify that");
                out.println("<br>");
                out.println("<a href='./Signin.html' target='_parent'>Do u want to Signin again</a>");
                out.println("</html>");
                con.close();
            }
        }
        catch(Exception e)
        {   try {
			con.close();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
            e.printStackTrace();
        }
        finally{
        	try {
    			con.close();
    		} catch (SQLException e1) {
    			e1.printStackTrace();
    		}
        }
    }
}
