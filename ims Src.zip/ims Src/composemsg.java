
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class composemsg extends HttpServlet
{

    public composemsg()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        PrintWriter out = res.getWriter();
        String option = req.getParameter("comp");
        String username = session.getAttribute("username").toString();
        String To = req.getParameter("To");
        String Cc = req.getParameter("Cc");
        String Bcc = req.getParameter("Bcc");
        String sub = req.getParameter("sub");
        String msg = req.getParameter("message");
        String file1 = req.getParameter("file1");
        String file2 = req.getParameter("file2");
        String file3 = req.getParameter("file3");
        System.out.println(file1);
        System.out.println(file2);
        System.out.println(file3);
        String filecontent1 = null;
        String filecontent2 = null;
        String filecontent3 = null;
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        String d2 = dateFormat.format(date);
        Connection con=null;
        if(To.equals(""))
        {
            out.println("<html><body bgcolor='#99CCFF'>");
            out.println("<center>");
            out.println("Filling up the To field is mandatory");
            out.println("</center>");
        } else
        {
            Vector v = new Vector();
            try
            {
                //Class.forName("oracle.jdbc.driver.OracleDriver");
               Class.forName("oracle.jdbc.driver.OracleDriver");
               con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ims","ims");
                Statement stmt = con.createStatement();
                out.println("<html><body>");
                out.println("<br>");
                out.println("<center>Welcome to " + username + "@mailingsystem.com</center>");
                out.println("<br>");
                String strs = null;
                for(StringTokenizer stTo = new StringTokenizer(To, ","); stTo.hasMoreElements();)
                {
                    strs = stTo.nextElement().toString();
                    ResultSet rs = stmt.executeQuery("select * from new_users_details where username='" + strs + "'");
                    if(rs.next())
                    {
                        if(option.equalsIgnoreCase("save as draft"))
                        {
                            PreparedStatement pstmt = con.prepareStatement("insert into draft values(?,?,?,?,?,?,?,?)");
                            pstmt.setString(1, username);
                            pstmt.setString(2, strs);
                            pstmt.setString(3, sub);
                            pstmt.setString(4, d2);
                            pstmt.setString(5, msg);
                            pstmt.setString(6, file1);
                            pstmt.setString(7, file2);
                            pstmt.setString(8, file3);
                            pstmt.executeUpdate();
                            v.addElement(username);
                            out.println("<center>ur msg has been sent to yours drafts </center>");
                            pstmt.close();
                        } else
                        {
                            filecontent1 = "";
                            filecontent2 = "";
                            filecontent3 = "";
                            try
                            {
                                FileInputStream fis = new FileInputStream(file1);
                                int ch;
                                while((ch = fis.read()) != -1) 
                                {
                                    filecontent1 = filecontent1 + (char)ch;
                                    System.out.print((char)ch);
                                }
                                System.out.println(filecontent1);
                                fis.close();
                                fis = new FileInputStream(file2);
                                while((ch = fis.read()) != -1) 
                                    filecontent2 = filecontent2 + (char)ch;
                                System.out.println(filecontent2);
                                fis.close();
                                fis = new FileInputStream(file3);
                                while((ch = fis.read()) != -1) 
                                    filecontent3 = filecontent3 + (char)ch;
                                System.out.println(filecontent3);
                                fis.close();
                                
                            }
                            catch(Exception exception) {}
                            PreparedStatement pstmt = con.prepareStatement("insert into inbox_details(SOURCE,DESTINATION,SUBJECT,DATE1,MESSAGE,ATTACH1,ATTACH2,ATTACH3,FILE1,FILE2,FILE3)" +
                            		" values(?,?,?,?,?,?,?,?,?,?,?)");
                            pstmt.setString(1, username);
                            pstmt.setString(2, strs);
                            pstmt.setString(3, sub);
                            pstmt.setString(4, d2);
                            pstmt.setString(5, msg);
                            pstmt.setString(6,filecontent1);
                            pstmt.setString(7, filecontent2);
                            pstmt.setString(8, filecontent3);
                            pstmt.setString(9, file1);
                            pstmt.setString(10, file2);
                            pstmt.setString(11, file3);
                            pstmt.executeUpdate();
                            v.addElement(To);
                            pstmt =con.prepareStatement("insert into sent_message values(?,?,?,?,?,?,?,?,?,?,?)");
                            
							pstmt.setString(1, username);
                            pstmt.setString(2, strs);
                            pstmt.setString(3, sub);
                            pstmt.setString(4, d2);
                            pstmt.setString(5, msg);
                            pstmt.setString(6, filecontent1);
                            pstmt.setString(7, filecontent2);
                            pstmt.setString(8, filecontent3);
                            pstmt.setString(9, file1);
                            pstmt.setString(10, file2);
                            pstmt.setString(11, file3);
                            pstmt.executeUpdate();
                            out.println("<center>ur msg has been sent to " + strs + "@mailingsystem.com</center>");
                            pstmt.close();
                            
                        }
                    } else
                    {
                        out.println("<center>ur destination id " + strs + " is not avilable. so plz checked it</center>");
                    }
                }

                if(!Cc.equals(""))
                {
                    for(StringTokenizer st = new StringTokenizer(Cc, ","); st.hasMoreElements();)
                    {
                        String str = st.nextElement().toString();
                        ResultSet rs1 = stmt.executeQuery("select * from new_users_details where username='" + str + "'");
                        if(rs1.next())
                        {
                            PreparedStatement pstmt = 
							con.prepareStatement("insert into inbox_details(SOURCE,DESTINATION,SUBJECT,DATE1,MESSAGE,ATTACH1,ATTACH2,ATTACH3,FILE1,FILE2,FILE3) values(?,?,?,?,?,?,?,?,?,?,?)");
                            pstmt.setString(1, username);
                            pstmt.setString(2, str);
                            pstmt.setString(3, sub);
                            pstmt.setString(4, d2);
                            pstmt.setString(5, msg);
                            pstmt.setString(6, filecontent1);
                            pstmt.setString(7, filecontent2);
                            pstmt.setString(8, filecontent3);
                            pstmt.setString(9, file1);
                            pstmt.setString(10, file2);
                            pstmt.setString(11, file3);
                            pstmt.executeUpdate();
                            v.addElement(str);
                            pstmt = 
							con.prepareStatement("insert into sent_message values(?,?,?,?,?,?,?,?,?,?,?)");
                            pstmt.setString(1, username);
                            pstmt.setString(2, str);
                            pstmt.setString(3, sub);
                            pstmt.setString(4, d2);
                            pstmt.setString(5, msg);
                            pstmt.setString(6, filecontent1);
                            pstmt.setString(7, filecontent2);
                            pstmt.setString(8, filecontent3);
                            pstmt.setString(9, file1);
                            pstmt.setString(10, file2);
                            pstmt.setString(11, file3);
                            pstmt.executeUpdate();
                            v.addElement(str);
                            out.println("<center>ur msg has been send to " + str + "@mailingsystem.com</center>");
                        } else
                        {
                            out.println("<center>ur destination id " + str + " is not avilable. so plz checked it</center>");
                        }
                    }

                }
                if(!Bcc.equals(""))
                {
                    String str1;
                    for(StringTokenizer st1 = new StringTokenizer(Bcc, ","); st1.hasMoreElements(); out.println("<center>ur msg has been send to " + str1 + "@mailingsystem.com</center>"))
                    {
                        str1 = st1.nextElement().toString();
                        ResultSet rs2 = stmt.executeQuery("select * from new_users_details where username='" + str1 + "'");
                        PreparedStatement pstmt = 
						con.prepareStatement("insert into inbox_details(SOURCE,DESTINATION,SUBJECT,DATE1,MESSAGE,ATTACH1,ATTACH2,ATTACH3,FILE1,FILE2,FILE3) values(?,?,?,?,?,?,?,?,?,?,?)");
                        pstmt.setString(1, username);
                        pstmt.setString(2, str1);
                        pstmt.setString(3, sub);
                        pstmt.setString(4, d2);
                        pstmt.setString(5, msg);
                        pstmt.setString(6, filecontent1);
                        pstmt.setString(7, filecontent2);
                        pstmt.setString(8, filecontent3);
                        pstmt.setString(9, file1);
                        pstmt.setString(10, file2);
                        pstmt.setString(11, file3);
                        pstmt.executeUpdate();
                        v.addElement(str1);
                        pstmt =con.prepareStatement("insert into sent_message values(?,?,?,?,?,?,?,?,?,?,?)");
                        pstmt.setString(1, username);
                        pstmt.setString(2, str1);
                        pstmt.setString(3, sub);
                        pstmt.setString(4, d2);
                        pstmt.setString(5, msg);
                        pstmt.setString(6, filecontent1);
                        pstmt.setString(7, filecontent2);
                        pstmt.setString(8, filecontent3);
                        pstmt.setString(9, file1);
                        pstmt.setString(10, file2);
                        pstmt.setString(11, file3);
                        pstmt.executeUpdate();
                        v.addElement(str1);
                    }

                }
                session.setAttribute("sent", v);
                session.setAttribute("msg", msg);
                session.setAttribute("sub", sub);
                session.setAttribute("dat", d2);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
}
