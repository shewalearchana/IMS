// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PasswordChange.java

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class PasswordChange extends HttpServlet
{

    public PasswordChange()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        PrintWriter out = res.getWriter();
        String username = session.getAttribute("username").toString();
        out.println("<html><body bgcolor='#99CCFF'>");
        out.println("<form action='./Change'>");
        out.println("<br>");
        out.println("<br>");
        out.println("<center>");
        out.println(username + " This is password change form");
        out.println("<br>");
        out.println("</center>");
        out.println("<center><table align='left'>");
        out.println("<tr><td>Old Password:</td><td><input type='password' name='old'></td></tr>");
        out.println("<tr><td>New Password:</td><td><input type='password' name='new'></td></tr>");
        out.println("<tr><td>Conform Password:</td><td><input type='password' name='cnew'></td></tr>");
        out.println("</table></center>");
        out.println("<br>");
        out.println("<center><input type='submit' name='cpwd' value='Change'></center>");
        out.println("</form></body></html>");
    }
}
