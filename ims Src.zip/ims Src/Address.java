import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Address extends HttpServlet
{

    public Address()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        PrintWriter out = res.getWriter();
        String username = session.getAttribute("username").toString();
        Connection con=null;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ims","ims");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from user_address_details where user_name='" + username + "'");
            out.println("<html><head><title>welcome to mailingsystem.com</title></head><body bgcolor='#99CCFF'>");
            out.println("<form action='./AddingNewAddress' target='right'>");
            out.println("<center><h3>");
            out.println("WELCOME TO " + username + "@mailingsystem.com");
            out.println("</h3></center>");
            out.println("<h3><b>Address</b></h3>");
            out.println("<table border='1'>");
            out.println("<tr>");
            out.println("<td> Name </td><td> NickName </td><td> Emailid </td><td> Address </td><td> Option </td>");
            out.println("</tr>");
            out.println("<br>");
            out.println("<br>");
            for(; rs.next(); out.println("</tr>"))
            {
                out.println("<tr>");
                out.println("<td>" + rs.getString(2) + "</td>");
                out.println("<td>" + rs.getString(3) + "</td>");
                String emailid = rs.getString(4);
                session.setAttribute("emailid", emailid);
                out.println("<td>" + emailid + "</td>");
                out.println("<td>" + rs.getString(5) + "</td>");
                out.println("<td><a href='./Delete' target='right'>delete</a>");
            }

            out.println("</table>");
            out.println("<center><input type='submit' name='add' value='Add'></center>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
            con.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
        finally{
        	try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
    }
}
