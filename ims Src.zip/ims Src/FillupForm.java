// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FillupForm.java

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FillupForm extends HttpServlet
{

    public FillupForm()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        javax.servlet.http.HttpSession session = req.getSession();
        PrintWriter out = res.getWriter();
        out.println("<html><head><script langauge='javascript'> function verifyUsername() {  var user=f1.username.value.charAt(0); if((user>='A' && user<='Z')  || (user>='a' && user<='z')){ x=0; } else { alert('First letter shold be an alphabet'); f1.username.focus();}} function verifyPassword() { if(f1.pwd.value.length<6) alert('Password should have minimum 6 characters');}</script><body bgcolor='#99CCFF'>");
        out.println("<form name='f1' action='./Fillup'>");
        out.println("<br>");
        out.println("<br>");
        out.println("<center>");
        out.println("<h1>FILL UP THE FORM</h1>");
        out.println("</center>");
        out.println("<br>");
        out.println("<br>");
        out.println("<center><table align='left' border='1'>");
        out.println("<tr><td>User Name:</td><td><input type='text' name='username' onkeyup='verifyUsername()'></td></tr>");
        out.println("<tr><td>User Password:</td><td><input type='password' name='pwd' onblur='verifyPassword()'></td></tr>");
        out.println("<tr><td>Confirm Password:</td><td><input type='password' name='cpwd'></td></tr>");
        out.println("<tr><td>Age:</td><td><input type='text' name='age'></td></tr>");
        out.println("<tr><td>Sex:</td><td><input type='text' name='sex'></td></tr>");
        out.println("<tr><td>City:</td><td><input type='text' name='city'></td></tr>");
        out.println("<tr><td>State:</td><td><input type='text' name='state'></td></tr>");
        out.println("<tr><td>Pincode:</td><td><input type='text' name='pin'></td></tr>");
        out.println("<tr><td>Nation:</td><td><input type='text' name='nation'></td></tr>");
        out.println("<tr><td>Question:</td><td><select name='question'><option>ur favourite star</option><option>favourite car</option><option>favourite Cricket player</option></td></tr>");
        out.println("<tr><td>Answer:</td><td><input type='text' name='answer'</td></tr>");
        out.println("</table></center>");
        out.println("<center><input type='submit' name='register' value='Register'></center>");
        out.println("<center><input type='reset' name='reset' value='Reset'></center>");
        out.println("</form></body></html>");
    }
}
