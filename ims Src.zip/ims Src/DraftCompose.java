// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DraftCompose.java

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class DraftCompose extends HttpServlet
{

    public DraftCompose()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        String username = session.getAttribute("username").toString();
        PrintWriter out = res.getWriter();
        String to = req.getParameter("to");
        String subject = req.getParameter("subject");
        String message = req.getParameter("message");
        out.println("<html><body bgcolor='#99CCFF'>");
        out.println("<form action='./composemsg'>");
        out.println("<br>");
        out.println("<center>");
        out.println("Welcome to " + username + "@mailingsystem.com");
        out.println("</center>");
        out.println("<br>");
        out.println("<center><table>");
        out.println("<tr><td>To:</td><td><input type='text' name='To' value=" + to + "></td></tr>");
        out.println("<br>");
        out.println("<tr><td>Subject:</td><td><input type='text' name='sub' value=" + subject + "></td></tr>");
        out.println("<br>");
        out.println("<tr><td>Cc:</td><td><input type='text' name='Cc'></td></tr>");
        out.println("<br>");
        out.println("<tr><td>Bcc:</td><td><input type='text' name='Bcc'></td></tr>");
        out.println("<br>");
        out.println("<tr><td>Send Message Area:</td></tr>");
        out.println("<br>");
        out.println("<tr><td><textarea name='message' rows='10' columns='60'>" + message + "</textarea></td></tr>");
        out.println("</table></center>");
        out.println("<center><input type='submit' name='comp' value='Send'></center>");
        out.println("<center><input type='submit' name='comp' value='Save as draft'></center>");
        out.println("</form></body></html>");
    }
}
