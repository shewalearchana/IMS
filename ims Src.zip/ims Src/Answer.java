
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Answer extends HttpServlet
{

    public Answer()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String question = null;
        HttpSession session = req.getSession();
        String user_answer = req.getParameter("answer").toString();
        String db_answer = null;
        String password = null;
        question = session.getAttribute("question").toString();
        String username = session.getAttribute("username").toString();
        Connection con=null;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ims","ims");
            Statement stmt = con.createStatement();
            for(ResultSet rs = stmt.executeQuery("SELECT answer,password from user_question where username='" + username + "' and question='" + question + "'"); rs.next();)
            {
                db_answer = rs.getString(1);
                password = rs.getString(2);
            }

            out.println("<html>");
            out.println("<body>");
            if(user_answer.equals(db_answer))
            {
                out.println("<center>");
                out.println("<br>User ID:" + username);
                out.println("<br>Password: " + password);
                out.println("<br><a href='./Signin.html'>Click here to Login</a>");
                out.println("</center>");
            } else
            {
                out.println("Invalid Login ID, Please try again");
                out.println("<a href='/Signin.html'>Click here to Login</a>");
            }
            out.println("</body>");
            out.println("</html>");
            con.close();
        }
        catch(Exception exception) { 
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        finally{
        	try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}  
      }
   }
}
