// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   NewAddress.java

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class NewAddress extends HttpServlet
{

    public NewAddress()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        PrintWriter out = res.getWriter();
        String username = session.getAttribute("username").toString();
        String name = req.getParameter("name").toString();
        String nname = req.getParameter("nname").toString();
        String emailid = req.getParameter("emailid").toString();
        String address = req.getParameter("address").toString();
        boolean flag = true;
        Connection con=null;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ims","ims");
            Statement stmt = con.createStatement();
            for(ResultSet rs = stmt.executeQuery("select fr_mailid from user_address_details where user_name='" + username + "'"); rs.next();)
            {
                System.out.println("in while");
                String str = rs.getString(1);
                if(str.equals(emailid))
                {
                    System.out.println("in if");
                    out.println("<html><body bgcolor='#99ccff'>");
                    out.println("<br>");
                    out.println("<center>");
                    out.println("Welcome to " + username + "@mailingsystem.com");
                    out.println("</center>");
                    out.println("<br>");
                    out.println("<center>");
                    out.println("This Address is already created");
                    out.println("</center>");
                    out.println("<br>");
                    out.println("u want Add NewAddress again click here:<a href='./AddingNewAddress' target='right'>Back</a>");
                    flag = false;
                }
            }

            if(flag)
                if(name.equals("") || nname.equals("") || emailid.equals("") || address.equals(""))
                {
                    out.println("<html><body bgcolor='#99ccff'>");
                    out.println("<center>");
                    out.println("Welcome to " + username + "@graybound.com");
                    out.println("</center>");
                    out.println("<br>");
                    out.println("<center>");
                    out.println("plz Fillup the all fields");
                    out.println("</center>");
                    out.println("<br>");
                    out.println("<a href='./AddingNewAddress' target='right'>Back</a>");
                } else
                {
                    PreparedStatement pstmt = con.prepareStatement("insert into user_address_details values(?,?,?,?,?)");
                    System.out.println("in prepare");
                    pstmt.setString(1, username);
                    pstmt.setString(2, name);
                    pstmt.setString(3, nname);
                    pstmt.setString(4, emailid);
                    pstmt.setString(5, address);
                    pstmt.executeUpdate();
                    System.out.println("after prepere");
                    out.println("<html><body bgcolor='#99CCFF'>");
                    out.println("<br>");
                    out.println("<center>");
                    out.println("Welcome to " + username + "@graybound.com");
                    out.println("</center>");
                    out.println("<br>");
                    out.println("<center>");
                    out.println("Ur New address " + name + " has been added to ur address box");
                    out.println("</center>");
                    out.println("u want Add NewAddress again click here:<a href='./AddingNewAddress' target='right'>Back</a>");
                    out.println("</body></html>");
                }
            con.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally{try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
    }
}
