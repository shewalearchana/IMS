import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Delete extends HttpServlet
{

    public Delete()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        PrintWriter out = res.getWriter();
        String emailid = session.getAttribute("emailid").toString();
        String username = session.getAttribute("username").toString();
        Connection con=null;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
             con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ims","ims");
            Statement stmt = con.createStatement(1005, 1008);
            int i = stmt.executeUpdate("delete user_address_details where user_name='" + username + "' and fr_mailid='" + emailid + "'");
            out.println("<html><body bgcolor='#99CCFF'>");
            out.println("<center>");
            out.println("Welcome To " + username + "@mailingsystem.com");
            out.println("</center>");
            out.println("<br>");
            out.println("<center>");
            out.println("ur friend address is delete:");
            out.println("</center>");
            con.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
        finally{
        	try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
    }
  }
}
