// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   UpdateFillup.java

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UpdateFillup extends HttpServlet
{

    public UpdateFillup()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        PrintWriter out = res.getWriter();
        String username = req.getParameter("username").trim();
        String pwd = req.getParameter("pwd").trim();
        String cpwd = req.getParameter("cpwd").trim();
        String age = req.getParameter("age").trim();
        String sex = req.getParameter("sex").trim();
        String city = req.getParameter("city").trim();
        String pin = req.getParameter("pin").trim();
        String nation = req.getParameter("nation").trim();
        String question = req.getParameter("question").trim();
        String answer = req.getParameter("answer").trim();
        Connection con=null;
        if(username.equals("") || pwd.equals("") || cpwd.equals("") || age.equals("") || sex.equals("") || city.equals("") || pin.equals("") || nation.equals(""))
        {
            out.println("<html><body bgcolor='#99CCFF'>");
            out.println("<center><h3>plz Fillup the all Fields in the FillupForm</h3></center>");
            out.println("<center>Do you want to back. plz click here:<a href='./FillupForm'>Back</a></center>");
            out.println("</body></html>");
        } else
        {
            try
            {
                Class.forName("oracle.jdbc.driver.OracleDriver");
                con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ims","ims");
                Statement stmt = con.createStatement();
                Statement stmt2 = con.createStatement();
                boolean flag = true;
                if(flag)
                    if(pwd.equals(cpwd))
                    {
                        int i = stmt.executeUpdate("UPDATE new_users_details SET userpwd='" + pwd + "',con_pwd='" + cpwd + "',user_age=" + age + ",user_city='" + city + "',user_nation='" + nation + "' where username='" + username + "'");
                        int j = stmt2.executeUpdate("UPDATE user_question SET  pwd='" + pwd + "', question='" + question + "',answer='" + answer + "' WHERE username='" + username + "'");
                        if(i == j)
                        {
                            session.setAttribute("password", pwd);
                            session.setAttribute("username", username);
                        }
                        out.println("<html><body bgcolor='#99CCFF'>");
                        out.println("<center><h1>WELCOME to mailingsystem</h1></center>");
                        out.println("<center><h3>");
                        out.println("Your user id is:" + username + "@mailingsystem.com");
                        out.println("</h3></center>");
                        out.println("<center>Do you want to Singin. plz click here:<a href='./Signin.html'>Signin</a></center>");
                        out.println("</body></html>");
                    } else
                    {
                        out.println("<html><body bgcolor='#99CCFF'>");
                        out.println("<center><h3>Error in ConformPassword</h3></center>");
                        out.println("<center>Do you want to back. plz click here:<a href='./UpdateForm'>Back</a></center>");
                        out.println("</body></html>");
                    }
                con.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            }
            finally{
            	try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        }
    }
}
