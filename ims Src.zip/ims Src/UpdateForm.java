import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UpdateForm extends HttpServlet
{

    public UpdateForm()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        PrintWriter out = res.getWriter();
        String username = null;
        String pwd = null;
        String cpwd = null;
        String sex = null;
        String city = null;
        String nation = null;
        String state = null;
        int age = 0;
        int pin = 0;
        String username1 = session.getAttribute("username").toString();
        String password = session.getAttribute("password").toString();
        Connection con=null;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ims","ims");
            Statement stmt = con.createStatement();
            for(ResultSet rs = stmt.executeQuery("SELECT * FROM new_users_details where username='" + username1 + "'"); rs.next();)
            {
                username = rs.getString(1);
                pwd = rs.getString(2);
                cpwd = rs.getString(3);
                age = rs.getInt(4);
                sex = rs.getString(5);
                city = rs.getString(6);
                pin = rs.getInt(7);
                nation = rs.getString(8);
            }
            con.close();
        }
        catch(Exception exception) { 
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        finally{try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
        out.println("<html><head><script langauge='javascript'> function verifyUsername() {  var user=f1.username.value.charAt(0); if((user>='A' && user<='Z')  || (user>='a' && user<='z')){ x=0; } else { alert('First letter shold be an alphabet'); f1.username.focus();}} function verifyPassword() { if(f1.pwd.value.length<6) alert('Password should have minimum 6 characters');}</script><body bgcolor='#99CCFF'>");
        out.println("<form name='f1' action='./UpdateFillup'>");
        out.println("<br>");
        out.println("<br>");
        out.println("<center>");
        out.println("<h1>FILL UP THE FORM</h1>");
        out.println("</center>");
        out.println("<br>");
        out.println("<br>");
        out.println("<center><table align='left' border='1'>");
        out.println("<tr><td>User Name:</td><td><input type='text' name='username' readonly value= '" + username + "' ></td></tr>");
        out.println("<tr><td>User Password:</td><td><input type='password' name='pwd' value='" + pwd + "' onblur='verifyPassword()'></td></tr>");
        out.println("<tr><td>Confirm Password:</td><td><input type='password' name='cpwd' value='" + cpwd + "'></td></tr>");
        out.println("<tr><td>Age:</td><td><input type='text' name='age' value='" + age + "'></td></tr>");
        out.println("<tr><td>Sex:</td><td><input type='text' name='sex' readonly value='" + sex + "'></td></tr>");
        out.println("<tr><td>City:</td><td><input type='text' name='city'value='" + city + "'></td></tr>");
        out.println("<tr><td>Pincode:</td><td><input type='text' name='pin' value='" + pin + "'></td></tr>");
        out.println("<tr><td>Nation:</td><td><input type='text' name='nation' value='" + nation + "'></td></tr>");
        out.println("<tr><td>Question:</td><td><select name='question'><option>ur favourite star</option>5<option>favourite car</option><option>favourite Cricket player</option></td></tr>");
        out.println("<tr><td>Answer:</td><td><input type='text' name='answer'value=''></td></tr>");
        out.println("</table></center>");
        out.println("<center><input type='submit' name='register' value='Register'></center>");
        out.println("<center><input type='reset' name='reset' value='Reset'></center>");
        out.println("</form></body></html>");
    }
}
