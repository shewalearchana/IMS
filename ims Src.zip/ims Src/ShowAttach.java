
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ShowAttach extends HttpServlet
{

    public ShowAttach()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        java.io.PrintWriter out = res.getWriter();
        String rid = req.getParameter("rowid");
        String username = session.getAttribute("username").toString();
        String file = req.getParameter("file");
        Connection con=null;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
             con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ims","ims");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from inbox_details where rowid='" + rid + "'");
            if(rs.next())
            {
                String file1 = rs.getString("file1");
                String file2 = rs.getString("file2");
                String file3 = rs.getString("file3");
                File f1 = new File(file1);
                File f2 = new File(file2);
                File f3 = new File(file3);
                String file11 = f1.getName();
                String file12 = f1.getName();
                String file13 = f1.getName();
                System.out.println(file1);
                System.out.println(file11);
                String content = "";
                Runtime r = Runtime.getRuntime();
                if(file11.equals(file))
                {
                    content = rs.getString("attach1");
                    Process p = r.exec("Notepad " + file1);
                } else
                if(file12.equals(file))
                {
                    content = rs.getString("attach2");
                    Process p = r.exec("Notepad " + file2);
                } else
                if(file13.equals(file))
                {
                    content = rs.getString("attach3");
                    Process process = r.exec("Notepad " + file1);
                }
                File f = new File(file);
                System.out.println(file);
                System.out.println(content);
                FileOutputStream fos = new FileOutputStream(f);
                fos.write(content.getBytes());
            }
            con.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
        finally{
        	try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        	}
    }
}
