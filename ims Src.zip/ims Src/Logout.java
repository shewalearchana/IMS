// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Logout.java

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Logout extends HttpServlet
{

    public Logout()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        PrintWriter out = res.getWriter();
        session.removeAttribute("username");
        session.removeAttribute("emailid");
        out.println("<html><body bgcolor='#99CCFF'>");
        out.println("<br>");
        out.println("<br>");
        out.println("<center>");
        out.println("TankYou for using our Mailing system");
        out.println("<br>");
        out.println("<br>");
        out.println("<a href='./Signin.html' target='_parent'>Do u want to Signin again</a>");
        out.println("</body></html>");
    }
}
