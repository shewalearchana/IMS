

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Inbox extends HttpServlet
{

    public Inbox()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        HttpSession session = req.getSession();
        PrintWriter out = res.getWriter();
        String username = session.getAttribute("username").toString();
        boolean flag = true;
        Connection con=null;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ims","ims");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select rowid,destination,subject,date1,contentfile1 from inbox_details where destination='" + username + "'");
            out.println("<html><body bgcolor='#99CCFF'>");
            out.println("<br>");
            out.println("<td><center>Welcome to " + username + "@mailingsystem.com</center></td>");
            out.println("<center><table align='left' border='1'>");
            out.println("<b><tr><td>From</td><td>Subject</td><td>Date</td><td>Option</td><td>Attachments</td></tr></b>");
            out.println("<br>");
            String rid;
            for(; rs.next();out.println("<td><a href='./inboxmsg?username="+ username +"'>FILE</a></td>"))
            {
                rid = rs.getString(1);
                System.out.println(rid);
                flag = false;
                out.println("<tr><td>" + rs.getString(2) + "</td>");
                out.println("<td><a href='./InboxMsgShow?rowid=" + rid + "'>" + rs.getString(3) + "</a></td>");
				
                out.println("<td>" + rs.getString(4) + "</a></td>");

//out.println("<td>"+rs.getString(5)+"</td>");
				
out.println("<td><a href='./DelInboxMsg?rowid=" + rid + "'>Delete</a></td>");


            }



            if(flag)
            {
                out.println("<br>");
                out.println("<center>Welcome to " + username + "@mailingsystem.com</center>");
                out.println("<br>");
                out.println("<center>you have no mails</center>");
                out.println("<br>");
                out.println("<center>Thankyou for using mailingsystem.com</center>");
            }
            out.println("</table></body></html>");
            con.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
        finally{
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    }
}
