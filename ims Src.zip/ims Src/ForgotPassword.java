// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ForgotPassword.java

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ForgotPassword extends HttpServlet
{

    public ForgotPassword()
    {
    }

    public void service(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String question = null;
        String username = req.getParameter("username");
        Connection con=null;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
             con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ims","ims");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT question from user_question where username='" + username + "'");
            HttpSession session = req.getSession();
            for(; rs.next(); session.setAttribute("question", question))
            {
                question = rs.getString(1);
                session.setAttribute("username", username);
            }

            con.close();
        }
        catch(Exception exception) {
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        finally{
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        out.println("<html>");
        out.println("<body>");
        out.println("<form action='./Answer'>");
        out.println("<pre>");
        out.println("<font color='green'>" + question + "</font>");
        out.println(" <br>Answer  :<input type='text' name='answer' value=''>");
        out.println("<br><input type='submit' value='Submit'/>");
        out.println("</pre>");
        out.println("</form>");
        out.println("</body>");
        out.println("</html>");
        
      }
}
